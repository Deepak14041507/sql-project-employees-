--   Gender Distribution in Each Department
-- Question: Write a query to find the gender distribution (number of males and females) in each department. 
-- Include department number, department name, count of males, and count of females.

select departments.dept_no,departments.dept_name,
sum(case when employees.gender='M' then 1 else 0 end) as male_count,
sum(case when employees.gender='F' then 1 else 0 end) as female_count
from departments join dept_emp
on departments.dept_no=dept_emp.dept_no
join employees 
on employees.emp_no=dept_emp.emp_no
group by departments.dept_no,departments.dept_name;