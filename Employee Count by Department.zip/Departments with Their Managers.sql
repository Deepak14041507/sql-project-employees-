-- Departments with Their Managers
-- Question: Write a query to list all departments along with their current managers.
-- Include department number, department name, manager’s employee number, 
-- first name, and last name.

select departments.dept_name,departments.dept_no,dept_manager.emp_no,
employees.first_name,employees.last_name from departments join dept_manager
on departments.dept_no=dept_manager.dept_no
join employees
on employees.emp_no=dept_manager.emp_no;