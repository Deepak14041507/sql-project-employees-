-- Employees with Specific Titles
-- Question: Write a query to find all employees who have held
-- a specific title (e.g., ‘Engineer’). Include employee number, first name, 
-- last name, and title.

select titles.emp_no,employees.first_name, employees.last_name,titles.title
from titles join employees
on titles.emp_no=employees.emp_no
where titles.title="engineer";