-- Employee Count by Department
-- Question: Write a query to count the number of employees in each department.
-- Include department number, department name, and employee count.

select departments.dept_no,departments.dept_name as dept_name,count(employees.emp_no) as employees_count
from departments join dept_emp
on departments.dept_no=dept_emp.dept_no
join employees
on employees.emp_no=dept_emp.emp_no
group by dept_name
order by employees_count desc;