-- list of employees by department

select employees.emp_no,employees.first_name,employees.last_name,departments.dept_no,departments.dept_name
from departments join dept_emp
on departments.dept_no=dept_emp.dept_no
join employees
on employees.emp_no=dept_emp.emp_no;